// pages/about/about.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    "wt":520
  },
  /**
   * 组件的方法列表
   */
  methods: {
    hahah: function (event) {
      console.log("you click");
    },
    tabControlClick(event){
        console.log(event);
    }
  }
})
